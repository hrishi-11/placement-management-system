admin username:-admin
admin password:-pms0710@admin

database name placement-management