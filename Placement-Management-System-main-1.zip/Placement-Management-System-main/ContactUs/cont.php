<!DOCTYPE html>
<html>
<head>
	<title>Contact us </title>
<link rel="stylesheet" type="text/css" href="cont.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
<link href='https://fonts.googleapis.com/css?family=Montserrat' rel='stylesheet' type='text/css'>

<!-- extra -->

<link href="https://fonts.googleapis.com/css2?family=Itim&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css"
    integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
<link href="https://fonts.googleapis.com/css2?family=Syncopate:wght@700&display=swap" rel="stylesheet">


<link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@700&display=swap" rel="stylesheet">
<script type="text/javascript" src="nav.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"
    integrity="sha512-HK5fgLBL+xu6dm/Ii3z4xhlSUyZgTT9tuc/hSrtw6uzJOvgRr2a9jyxxT1ely+B+xFAmJKVSTbpM/CuL7qxO8w=="
    crossorigin="anonymous" />
<script src="https://use.fontawesome.com/2c48ba5ff4.js"></script>
<script src="https://kit.fontawesome.com/a076d05399.js"></script>
<link rel="stylesheet" href="nav.css">


<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
<link rel="preconnect" href="https://fonts.gstatic.com">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"
    integrity="sha512-HK5fgLBL+xu6dm/Ii3z4xhlSUyZgTT9tuc/hSrtw6uzJOvgRr2a9jyxxT1ely+B+xFAmJKVSTbpM/CuL7qxO8w=="
    crossorigin="anonymous" />
<script src="https://use.fontawesome.com/2c48ba5ff4.js"></script>
<script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>

<!-- extra -->
</head>
<body>

<style>body{background-color:rgb(233, 245, 244);}</style> 

<!-- Navbar -->
<div id=unique>
    <header>

        <div class=" menu-toggle" id="hamburger">
            <i class="fas fa-bars"></i>
        </div>
        <div class="overlay"></div>
        <div class="container-fluid">
            
                    <nav>
          
                    <span>   <a style="font-family: 'Open Sans', sans-serif; "  class="navbar-brand" href="#">
                      <img
                              src="vu logo.png"
                              height="50"
                              alt=""
                             
                            /> 
                          </a></span>
                          <ul  style="font-family: 'Open Sans', sans-serif; ">
                          <li><a href="../home page/home-page.php">Home</a></li>
                                <li><a href="../AboutUs/about.html">About us</a></li>
                                <li><a href="../drive/drive.html">Campus Drive</a></li>
                                <li><a href="../ContactUs/cont.php">Contact Us</a></li>
                                <li><a href="../faq/faq.html">FAQ</a></li>
                                <li><a href="../commonlogin.php">Login</a></li>

                            </ul>
                    </nav>
        </div>
    </header>
</div>
<!-- Navbar -->


<div class="contactus">
    
<div id="cbb">

<h1 style="color:rgb(107, 107, 146);"><strong>Contact Us</strong></h1>

</div>
</div>


<div class="container">

<div class="col-md-1"></div>
<div class="col-md-6" >
<form  action="process.php" method="post">
    <div class="det"><i class="fa fa-map-marker"></i> Vishwakarma University Survey No 2,3,4 Laxminagar, Kondhwa (Bk.) Pune 411048</div>
    <div class="det"><i class="fa fa-phone"></i> 93 700 34 794</div>
    <div class="det"><i class="fa fa-globe"></i> https://www.vupune.ac.in/</div>

<br><br><br>

<input type="text" title="Your Name" class="name" class="form-control" placeholder="Your Name*" name="name">
<br>
<br>
<input type="email"  title="Email Address" class="mail" class="form-control" name="email" placeholder="Email Address*" style="width:47%;">

&nbsp;&nbsp;<input type="numbers" class="mail" title="Number" name="number" required class="form-control" placeholder="+91" style="width:50%;">

<br>
<br>

<input type="text" placeholder="Message" class="message"  name="message" title="Message" class="form-control">
<br>
<br>


<br>
<br>
<button type="submit" class="bttn" title="Submit Post"  class="form-control" >Submit
</button><br>
</select>

</div>
</form>


<div class="col-md-5"  class="responsive">
<br>
<br>
<br>

<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3573.643777765392!2d75.87287571487165!3d26.402693883349844!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bbfc0c282ffffff%3A0x4776f298b0f0587e!2sBanasthali%20University!5e0!3m2!1sen!2sin!4v1615109744787!5m2!1sen!2sin" width="100%" height="400px" frameborder="0" style="border:0;" allowfullscreen></iframe>

<br>
</div>
</div>	
</body>
</html>