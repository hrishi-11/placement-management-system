jQuery(function($) {
    $('.flexslider').flexslider({
      animation: "slide"
    });
  });
  