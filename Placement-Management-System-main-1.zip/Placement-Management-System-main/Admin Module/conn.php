<?php
$db=mysqli_connect('localhost:8080','root','','placement-management');
 ?>