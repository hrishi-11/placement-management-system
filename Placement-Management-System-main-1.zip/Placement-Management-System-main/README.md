# Placement-Management-System


This website is basically a placement management system which is designed to provide the details of its students in a database for the companies to their process of recruitment provided with a proper login . The system stores all the personal information of the students and their technical skills that are required in the CV to be sent to a company. The system is an online application that can be accessed throughout the organization and outside as well with proper login provided.
